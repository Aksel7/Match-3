#ifndef CONFIG_H
#define CONFIG_H

#define LIGNES 9      
#define COLONNES 9    
#define VIES_INIT 3
#define FICHIER_SAUVEGARDE "sauvegarde.txt"

#endif
