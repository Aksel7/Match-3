#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <conio.h>
#include <windows.h>

#include "partie.h"
#include "jeu.h"
#include "affichage.h"
#include "musique.h"

void sauvegarderPartie(char pseudo[], int niveau, int vies) {
    FILE *f = fopen(FICHIER_SAUVEGARDE, "a");
    if (f) {
        fprintf(f, "%s %d %d\n", pseudo, niveau, vies);
        fclose(f);
        printf("\nSauvegarde OK.\n");
    }
}

int chargerSauvegarde(char pseudo[], int *niveau, int *vies) {
    FILE *f = fopen(FICHIER_SAUVEGARDE, "r");
    char pLu[50];
    int nLu, vLu;
    int trouve = 0;
    
    if (!f) return 0;

    while (fscanf(f, "%s %d %d", pLu, &nLu, &vLu) == 3) {
        if (strcmp(pLu, pseudo) == 0) {
            *niveau = nLu;
            *vies = vLu;
            trouve = 1;
        }
    }
    fclose(f);
    return trouve;
}

// niveau

int lancerNiveau(char pseudo[], int niveau, int *vies, int musiqueActive) {
    int grille[LIGNES][COLONNES];
    int objectifs[6] = {0};
    int progression[6] = {0};
    int total_cases = LIGNES * COLONNES;
    
    int cX = LIGNES / 2;
    int cY = COLONNES / 2;
    int selActive = 0;
    int sX = -1, sY = -1;
    int running = 1;

    // difficulte
    int coups_max = 20 + (total_cases / 40) + (niveau * 2);
    if (coups_max > 80) coups_max = 80;
    int coups = coups_max;

    int temps_total = 60 + (total_cases / 10);
    if (temps_total > 300) temps_total = 300;

    // init
    creation_grille(grille);
    
    // clean debut
    int poubelle[6] = {0};
    resoudre_plateau(grille, poubelle); 

    genererObjectifs(niveau, objectifs);

    time_t debut = time(NULL);
    int tempsRestant = temps_total;
    int dernierTempsAffiche = temps_total;
    int besoinRafraichissement = 1;

    hide_cursor(); 
    clrscr(); 

    // musique si activee
    if (musiqueActive) lancerMusique();

    while (running && coups > 0 && tempsRestant > 0) {

        // timer
        int ecoule = (int)difftime(time(NULL), debut);
        tempsRestant = temps_total - ecoule;

        if (tempsRestant != dernierTempsAffiche) {
            dernierTempsAffiche = tempsRestant;
            besoinRafraichissement = 1;
        }

        // verif win
        if (verif_victoire(objectifs, progression)) {
            if (musiqueActive) arreterMusique();
            clrscr();
            if (tempsRestant < 0) tempsRestant = 0;
            
            afficherInfosHUD(pseudo, niveau, coups, *vies, objectifs, progression, tempsRestant);
            afficherPlateau(grille, cX, cY, selActive, sX, sY);
            
            text_color(LIGHTGREEN);
            printf("\n\n*** VICTOIRE ! Niveau termine ! ***\n");
            text_color(WHITE);
            show_cursor();
            system("pause");
            return 1;
        }

        // affichage
        if (besoinRafraichissement) {
            hide_cursor();
            clrscr();
            if (tempsRestant < 0) tempsRestant = 0;
            
            afficherInfosHUD(pseudo, niveau, coups, *vies, objectifs, progression, tempsRestant);
            afficherPlateau(grille, cX, cY, selActive, sX, sY);
            
            besoinRafraichissement = 0;
        }

        // inputs
        if (kbhit()) {
            char touche = getch();
            besoinRafraichissement = 1;

            switch (touche) {
                case 'p': // pause
                    if (musiqueActive) arreterMusique();
                    show_cursor();
                    return 0; 
                
                case 'z': if (cX > 0) cX--; break;
                case 's': if (cX < LIGNES - 1) cX++; break;
                case 'q': if (cY > 0) cY--; break;
                case 'd': if (cY < COLONNES - 1) cY++; break;

                case ' ':
                    if (!selActive) {
                        selActive = 1; 
                        sX = cX; sY = cY;
                    } else {
                        int dist = abs(cX - sX) + abs(cY - sY);
                        
                        if (dist == 1) { 
                            int tmp = grille[cX][cY]; 
                            grille[cX][cY] = grille[sX][sY]; 
                            grille[sX][sY] = tmp;

                            int combo = resoudre_plateau(grille, progression);

                            if (combo) {
                                coups--; 
                                selActive = 0;
                            } else {
                                tmp = grille[cX][cY]; 
                                grille[cX][cY] = grille[sX][sY]; 
                                grille[sX][sY] = tmp;
                                selActive = 0;
                            }
                        } else {
                            selActive = 0;
                        }
                    }
                    break;
            }
        } else {
            Sleep(50); 
        }
    }

    // perdu
    if (musiqueActive) arreterMusique();
    show_cursor();
    printf("\n\n");
    text_color(LIGHTRED);
    if (tempsRestant <= 0) printf("DEFAITE... Temps ecoule !\n");
    else printf("DEFAITE... Plus de coups disponibles.\n");
    
    text_color(WHITE);
    system("pause");
    return 0; 
}