#ifndef MUSIQUE_H
#define MUSIQUE_H

void lancerMusique();
void arreterMusique();

#endif